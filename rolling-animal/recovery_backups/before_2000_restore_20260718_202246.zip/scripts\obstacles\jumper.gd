class_name Jumper
extends StaticBody2D

@export_range(0.4, 2.0, 0.05) var minimum_bounce_size := 1.0
@export var medium_launch_velocity := -1765.0
@export var maximum_launch_velocity := -2150.0
@export var retrigger_delay := 0.25

@onready var spring_out: Sprite2D = $SpringOut
@onready var spring_in: Sprite2D = $SpringIn
@onready var detection_area: Area2D = $DetectionArea

var _ready_to_bounce := true


func _ready() -> void:
	detection_area.body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if not _ready_to_bounce or not (body is SoftPlayer):
		return
	var player := body as SoftPlayer
	var size_scale := player.get_current_size_scale()
	if size_scale < minimum_bounce_size or player.velocity.y < 0.0:
		return
	_ready_to_bounce = false
	var weight := inverse_lerp(minimum_bounce_size, player.maximum_size_scale, size_scale)
	player.velocity.y = lerpf(medium_launch_velocity, maximum_launch_velocity, clampf(weight, 0.0, 1.0))
	_play_bounce_visual()
	await get_tree().create_timer(retrigger_delay).timeout
	_ready_to_bounce = true


func _play_bounce_visual() -> void:
	spring_out.visible = false
	spring_in.visible = true
	await get_tree().create_timer(0.09).timeout
	spring_in.visible = false
	spring_out.visible = true
