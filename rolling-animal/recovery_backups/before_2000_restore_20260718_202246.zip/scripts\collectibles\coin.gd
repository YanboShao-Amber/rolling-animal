class_name CollectibleCoin
extends Area2D

signal collected(value: int)

@export var coin_id := ""
@export var level_id := "farm_level_1"
@export_range(1, 99, 1) var value := 1
@export var animation_speed := 10.0

@onready var sprite: Sprite2D = $Sprite2D

var _frames: Array[Texture2D] = [
	preload("res://assets/coin/gold_1.png"),
	preload("res://assets/coin/gold_2.png"),
	preload("res://assets/coin/gold_3.png"),
	preload("res://assets/coin/gold_4.png"),
]
var _time := 0.0
var _taken := false


func _ready() -> void:
	if coin_id.is_empty():
		coin_id = str(get_path())
	var game_state := get_node_or_null("/root/GameState")
	if game_state and game_state.is_level_coin_collected(level_id, coin_id):
		queue_free()
		return
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	_time += delta * animation_speed
	sprite.texture = _frames[int(_time) % _frames.size()]


func _on_body_entered(body: Node2D) -> void:
	if _taken or not (body is SoftPlayer):
		return
	_taken = true
	var game_state := get_node_or_null("/root/GameState")
	if game_state:
		game_state.collect_level_coin(level_id, coin_id, value)
	collected.emit(value)
	var tween := create_tween().set_parallel(true)
	tween.tween_property(self, "scale", Vector2(1.35, 1.35), 0.12)
	tween.tween_property(self, "modulate:a", 0.0, 0.12)
	await tween.finished
	queue_free()
