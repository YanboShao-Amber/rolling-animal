class_name FarmFallingColumn
extends StaticBody2D

signal player_stunned(player: SoftPlayer)

const STUN_EFFECT := preload("res://scenes/effects/StunEffect.tscn")

@export var break_size := 1.3
@export var fall_duration := 0.55
@onready var detection_area: Area2D = $DetectionArea

var _resolved := false


func _ready() -> void:
	detection_area.body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if _resolved or not (body is SoftPlayer):
		return
	var player := body as SoftPlayer
	if player.get_current_size_scale() >= break_size:
		_resolved = true
		fall_over()
	else:
		_resolved = true
		var effect := STUN_EFFECT.instantiate()
		player.add_child(effect)
		effect.position = Vector2(0, -80)
		player_stunned.emit(player)


func fall_over() -> void:
	detection_area.set_deferred("monitoring", false)
	var tween := create_tween().set_trans(Tween.TRANS_BOUNCE).set_ease(Tween.EASE_OUT)
	tween.tween_property(self, "rotation", PI * 0.5, fall_duration)
